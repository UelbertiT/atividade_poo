package com.mycompany.exerciciooverride;

public class Animal {
    
  public void emitirSom(){
         System.out.println("O animal emitiu um som. ");
        }
  public void mover (){
      System.out.println("O animal se movel");
       }
   }
